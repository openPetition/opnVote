'use client';
import React, { useState, useEffect } from "react";

export default function Head() {




    return (
      <>

<div className="z-10 max-w-5xl w-full items-center justify-between font-mono text-sm lg:flex">
        <div id="logo"></div>
        <div>
        </div>
      </div>

      </>
    )
}